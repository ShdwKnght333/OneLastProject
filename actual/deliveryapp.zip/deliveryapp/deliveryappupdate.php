<?php
$db_name="glo11449_fzdata";
$mysql_username="glo11449";
$mysql_password="somil.2792";
$server_name="www.foodzoned.com";

$conn = mysqli_connect($server_name,$mysql_username,$mysql_password,$db_name);
if($conn->connect_errno){
	die('connection not successful');
}

$order_id = $_POST["orderid"];
$status = $_POST["orderStatus"];
$paid = $_POST["amountpaid"];

$query = "UPDATE orders SET status_agent = '$status'  WHERE id = '$order_id'";
mysqli_query($conn,$query);
$query = "UPDATE orders SET paid_agent = '$paid' WHERE id = '$order_id'";
mysqli_query($conn,$query);

mysqli_close($conn);

?>