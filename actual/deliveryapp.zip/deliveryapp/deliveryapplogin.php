<?php
$db_name="glo11449_fzdata";
$mysql_username="glo11449";
$mysql_password="somil.2792";
$server_name="www.foodzoned.com";
$conn = mysqli_connect($server_name,$mysql_username,$mysql_password,$db_name);
if($conn->connect_errno){
	die('connection not successful');
}
$user_name = $_POST["user_name"];
$user_pass = $_POST["password"];

$mysql_qry = "select id from agent_login where user_id like '$user_name' and password like '$user_pass';";
$result = mysqli_query($conn ,$mysql_qry);
if($result) {
	$row=mysqli_fetch_array($result);
	echo $row[0];
}

?>