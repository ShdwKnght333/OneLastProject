<?php
$db_name="glo11449_fzdata";
$mysql_username="glo11449";
$mysql_password="somil.2792";
$server_name="www.foodzoned.com";

$conn = mysqli_connect($server_name,$mysql_username,$mysql_password,$db_name);
if($conn->connect_errno){
	die('connection not successful');
}

$agent_id = $_POST["id"];

$query = "SELECT orders.*,rests.name,rests.servicetime,rests.gsm FROM orders,rests WHERE orders.resid = rests.id AND rests.agent_id = '$agent_id' AND orders.status = 2 ORDER BY orders.id DESC";
$results = mysqli_query($conn,$query);

if($results){
	while($row=mysqli_fetch_array($results))
	{
		$flag[]=$row;
	}
	print(json_encode($flag));
}

mysqli_close($conn);

?>