<?php

//restaurant fax no : $fax_no
//fax msg : $fax_msg
//order id : $orderId

//fax functions will be here....

?>