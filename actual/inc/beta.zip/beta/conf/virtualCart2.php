<div class='desktop-cart__order'><div class='checkout__summary' style='max-height:62.0313px;'><table class='summary__items desktop-cart__products' style='width:100%;'><tbody class='cart__item'><!-- ITEM HEADER -->
<tr style="border-bottom:1px solid #ddd;"><td><b>Item</b></td><td><center><b>Qty &nbsp;</b></center></td><td style="text-align:right;"><b>Price</b></td><td></td></tr>
<tr>
<!-- ITEM NAME -->
<td style="font-size:12px;padding:0px;padding-top:8px;width: 60%;">South Indian Meal 

</td>
<!-- ITEM QUANTITY -->
<td style="width:20%;font-size:14px;padding-top:8px;"><center>
1&nbsp;
</center>
</td>
<!-- ITEM PRICE -->
<td style="text-align:right;width:20%;font-size:12px;padding-top:8px;">
<span class='fa fa-inr' >&nbsp;</span>70</td>
</tr>
</td></tr><tr>
<!-- ITEM NAME -->
<td style="font-size:12px;padding:0px;padding-top:8px;width: 60%;">Vada Sambhar(1Pc) 

</td>
<!-- ITEM QUANTITY -->
<td style="width:20%;font-size:14px;padding-top:8px;"><center>
1&nbsp;
</center>
</td>
<!-- ITEM PRICE -->
<td style="text-align:right;width:20%;font-size:12px;padding-top:8px;">
<span class='fa fa-inr' >&nbsp;</span>20</td>
</tr>
</td></tr></tbody>
</table>
 </div>
</div><!-- Actual Cart Ends -->
<div class="desktop-cart__footer"><!-- OUTER CONTAINER -->
<div class="desktop-cart__order__subtotal-container"> <!-- INNER CONTAINER -->
		<!-- SUB TOTAL -->
		<div class="desktop-cart__order__subtotal">
				<span>Subtotal</span><span class="desktop-cart__order__subtotal-price">₹ 90.00</span>
       </div>
    <!-- EXTRAS To be Added later in CSS-->	
	
		
	 <!-- TAXES IF ANY -->	  
						<div class="desktop-cart__order__vat">
				<span>Taxes &nbsp; <span class="desktop-cart__order__vat-price desktop-cart__order__vat-total">₹ 0.00</span></span>
			</div>
						
		 <!-- Delivery FEE IF ANY  -->	
		  <div class="desktop-cart__order__delivery">
        <span>Delivery charge &nbsp; <span class="desktop-cart__order__delivery-price">₹ 20.00</span></span>
        </div>
		 

		 <!-- DISCOUNT IF ANY  -->
					
			 <!-- FINAL CART TOTAL  -->
			 			<div class="desktop-cart__order-total-container">
			<div class="desktop-cart__order__total">
            <span><b><em class="desktop-cart__order__total-note">Total &nbsp; 
            <span class="desktop-cart__order__total-price">₹ 110.00</span></em></b></span>
			</div>
		  </div>
     </div><!-- INNER CONTAINER END-->
	 </div><!-- OUTER CONTAINER END-->

