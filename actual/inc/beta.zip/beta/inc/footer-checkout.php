	<footer class="site-footer-check">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<nav class="footer-nav clearfix">
						<ul class="cta footer-menu-check">							
							<li><a href="privacy.php">Privacy Policy</a></li>
                            <li><a href="terms.php">Terms and Conditions</a></li>                                                        
                        </ul> <!-- /.footer-menu -->
					</nav> <!-- /.footer-nav -->
				</div> <!-- /.col-md-12 -->
			</div> <!-- /.row --><br>
			<div class="row center">
            <div class="social">
            		<a href="http://facebook.com/Foodzoned" target="_blank"><i class="fa fa-facebook-square fa-2x"></i></a>
                    <a href="http://twitter.com/foodzoned" target="_blank"><i class="fa fa-twitter-square fa-2x"></i></a>
                    <a href="http://plus.google.com/102345729917238565603/" target="_blank"><i class="fa fa-google-plus-square fa-2x"></i></a>
                    <a href="http://instagram.com/foodzoned_happyordering" target="_blank"><i class="fa fa-instagram fa-2x"></i></a>
                    <a href="http://youtube.com/foodzoned" target="_blank"><i class="fa fa-youtube-square fa-2x"></i></a><br>
            </div>
            	<div class="col-md-12">
				<div class="cop visible-sm visible-md visible-lg" style="line-height:10px;">
                	<p class="copyright-text" style="margin-bottom:0px;"><img src="images/left.png" height="32px"width="64px"><?php echo $copyright;?><img src="images/right.png" height="32px"width="64px"></p>
					<span style="font-size:small">Make in India</span>
				</div>
				<div class="cop visible-xs">
                	<p class="copyright-text"><?php echo $copyright;?></p>
				</div>
				</div> <!-- /.col-md-12 -->
			</div> <!-- /.row -->
		</div> <!-- /.container -->
	</footer> <!-- /.site-footer -->
    <a href="#0" class="cd-top">Top</a>