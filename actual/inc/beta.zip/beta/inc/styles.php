    <!----TNAHSUS----->
	<link rel="shortcut icon" href="images/includes/favicon.ico" type="image/x-icon" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	
	<!-- Google Fonts -->
	
	<!-- Stylesheets -->
	<link rel="stylesheet" href="bootstrap/bootstrap.css">
	<link rel="stylesheet" href="css/misc.css">
	<link rel="stylesheet" href="css/red-scheme.css">
    <link type="text/css" rel="stylesheet" href="css/loginstyle.css" />
  	<link rel="stylesheet" href="css/b2tstyle.css"> <!-- Gem style -->
	<link type="text/css" rel="stylesheet" href="css/anireset.css" />
	
	<!-- JavaScripts -->
	<script src="js/jquery-1.10.2.min.js"></script>
	<script src="js/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/plugins/jquery.smoothscroll.js"></script>
	<script src="bootstrap/bootstrap.min.js"></script>
	<script src="js/modernizr.js"></script> <!-- Modernizr -->

	<!-- start of sweetAlert -->
	<script src="js/sweetalert/lib/sweet-alert.min.js"></script>
	<link rel="stylesheet" type="text/css" href="js/sweetalert/lib/sweet-alert.css">
 <!-- End of sweetAlert -->
	
    <link href="themes/font-awesome-4.6.3/css/font-awesome.min.css" rel="stylesheet">

