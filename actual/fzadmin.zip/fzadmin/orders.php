<? 
include "../conf/config.php";
include "check_login.php";

$_SESSION["actual_link"] = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

?>

<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Orders</title>
<? include "styles.php";  ?>
<script>
function set_OrderStatus(id,val) {
setTimeout( function(){
	if (confirm("Are you sure?")) {
	$("#result").load("../conf/post_admin.php?cmd=set_order_status&back=<?=$_SERVER['PHP_SELF']?>&id="+id+"&val="+val);
}
}, 200); }
</script>
</head>
<body>

<? include "header.php"; ?>

<div id="content">
<div id="container">
<h1 class="h1">Orders</h1>

 <form id="sss" action="<?=$_SERVER['PHP_SELF']?>" method="GET"> 
Order Id: <input type="text" name="q" id="q" value="<?=$_REQUEST['q']?>" style="width:67px;" /> <select name="status" id="status" style="font-size:14px;color:blue;font-weight:bold;">
	<option value="">--- All orders ---</option>
	<?
	$getRss = mysql_query("SELECT * FROM order_statuses order by id asc");
	while ($rss = mysql_fetch_array($getRss)) {
	?>
	<option value="<?=$rss['id']?>" <? if ($_REQUEST['status']==$rss['id']) echo "selected"; ?>><?=$rss['status']?></option>
	<? } ?>
	</select> <input type="submit" value="Search" /> &nbsp; &nbsp; &nbsp; &nbsp; ( Orders sorted according to Date )
</form>  
<br />

<table width="100%">
  <tr>
    <td width="20%" class="tdheader">Date/Total</td>
    <td width="28%" class="tdheader">Shipping Address</td>
    <td width="28%" class="tdheader">Order Details</td>
    <td width="24%" class="tdheader" style="text-align:center;">Status</td>
  </tr>
  <?
  
if ($_GET['s'] == "") $start = 0;
else $start = $_GET['s'];
$limit = 15;
@mysql_query("delete from orders where totalprice=0");


if ($_REQUEST['q']) {
	$q=safe($_REQUEST['q']);
	$addsql=" where id=".intval($q)."";
	$additionalVars.="&q=".$q;
}

if (!$_REQUEST['q']) {

$status=$_REQUEST['status'];
if ($_REQUEST['status']) { $addsql="where status=".intval($status).""; }
$additionalVars.="&status=".$status;

if ($_REQUEST['status'] == "error") { $addsql="where status > 9"; $additionalVars="&status=error"; }

}


$totalResults = getSqlNumber("SELECT id FROM orders $addsql");
$getRs = mysql_query("SELECT * from orders $addsql order by orderdate desc LIMIT ".$start.",".$limit." ");
/* $getRs = mysql_query("SELECT * from orders $addsql order by status asc, orderdate desc LIMIT ".$start.",".$limit." "); */
while ($rs = @mysql_fetch_array($getRs)) {

$class=(($count++)%2==0)?"tda":"tdb";
if (!$rs['deliverydate']) $rs['deliverydate']="Right Now";
$need_address=getWhere("order_types","need_address","order_type='".$rs['order_type']."'");
?>
  <tr>
    <td class="<?=$class?>"><br />

	<b>ID : <?=$rs['id']?></b>
	<br /><b><?=setPrice($rs['order_total']);?></b><br />
	<?=getVal("rests","name",$rs['resid'])?><br />
	Ph: <?=getVal("rests","gsm",$rs['resid'])?><br />
	<?=getVal("rests","address",$rs['resid'])?><br />
	<?=getVal("rests","rcity",$rs['resid'])?><br />
	<?=date('g:iA (d-m-y)', strtotime($rs['orderdate']));?><br />
<? if ( $rs['discount'] > 0 ) { ?> Rest. Discount: <?=setPrice($rs['discount']);?><br /> <? } ?>
<?if ($rs['delivery_type']==1)
		$output= '<span style = "color: #ff0000">SELF</span>';
	else
		$output= '<span style = "color: #0000FF">EXPRESS</span>';
	?>
	DELIVERY: <?echo $output ?>
	<br/>
	<br /></td>

    <td class="<?=$class?>"><br />
    Member ID: <a href="user.php?id=<?=$rs['userid']?>"><?=$rs['userid']?></a><br />
	Name : <?=$rs['name']?><br />

	<? /* ?> <b>Delivery Date:</b>	<?=$rs['deliverydate']?><br /> <? */ ?>
	Address: <?=nl2br($rs['address'])?><br /><?=$rs['postcode']?><br /><?=$rs['city']?><br />

	Mobile : <?=$rs['mobilphone']?>
	<? if ($rs['order_note']) { ?>
	<br />Order Note : <?=nl2br($rs['order_note'])?>
	<? } ?>
	<br /><br /></td>

    <td class="<?=$class?>"><br />
	
	<?
	$order_details="";
$getRss = mysql_query("SELECT * FROM order_details where orderid=".$rs['id']." order by id asc");
	while ($rss = mysql_fetch_array($getRss)) {
		$prod = getSqlField("SELECT name FROM products WHERE id=".$rss['prodid']."","name");
		$order_details.="- ".$rss['qty']." x ".$prod."<br />";
		if ($rss['optionals']) $order_details.="<span style='font-size:10px;line-height:14px;'>".$rss['optionals']."</span>";
	}
	echo $order_details;
	?>
	
	<br /><br /></td>

    <td class="<?=$class?>"><br />
	<select name="status" id="status" onchange='set_OrderStatus(<?=$rs['id'];?>,this.value);' style="font-size:14px;color:blue;font-weight:bold;">
	<?
	$getRss = mysql_query("SELECT * FROM order_statuses  order by id asc");
	while ($rss = mysql_fetch_array($getRss)) {
	?>
	<option value="<?=$rss['id']?>" <? if ($rs['status']==$rss['id']) echo "selected"; ?>><?=$rss['status']?></option>
	<? } ?>
	</select>

<br /><br />Order type: <?=$rs['order_type']?><br />
Payment: <?=$rs['paymenttype'];?><br />



	<? if ( strtolower($rs['paymenttype']) !== "cod" ) { ?>
	Payment Status: <?=$rs['payment_status'];?><br />
	OP ID: <?=$rs['tracking_id'];?><br />
	Bank Ref.: <?=$rs['bank_ref_no'];?><br />
	Mode: <?=$rs['payment_mode'];?><br />
	Via: <?=$rs['card_name'];?><br />
	Paid: <?=setPrice($rs['paid_amount']);?>
	<? } ?>

	<br /><br /></td>
  </tr>
<? } ?>
</table>
<br />

<div class="pagination">
<ul>
<?
pages($start,$limit,$totalResults,$_SERVER['PHP_SELF'],$additionalVars);
?>
</ul>
</div>

</div>
</div>

<? include "footer.php"; ?>

</body>
</html>