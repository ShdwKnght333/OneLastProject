				
<br/><br/>	
                </div>
            </div>
        </div>

    </div>
    <!-- /#wrapper -->

<div id="result"></div>

    <!-- Core Scripts - Include with every page -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/sb-admin.js"></script>


<?
if ($dbh[0] != 0) {
mysql_close($dbh);
}
?>