<link rel="stylesheet" type="text/css" media="all" href="<?=SITEURL?>css/reset.css" />
<link rel="stylesheet" type="text/css" media="all" href="<?=SITEURL?>css/style.css" />
<script type="text/javascript" src="<?=SITEURL?>js/jquery.js"></script>
<script type="text/javascript" src="<?=SITEURL?>js/jquery.color.js"></script>
<script type="text/javascript" src="<?=SITEURL?>js/site-main-fun.js"></script>

    <!-- Core CSS - Include with every page -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">

    <!-- SB Admin CSS - Include with every page -->
    <link href="css/sb-admin.css" rel="stylesheet">


<style>

.input-text {
  padding: 6px 8px;
  margin-bottom:10px;
  line-height: 1.428571429;
  border: 1px solid #ccc;
  border-radius: 3px;
}

.input-text:focus { 
    outline: none;
    border-color: #9ecaed;
    box-shadow: 0 0 3px #9ecaed;
}

.b22 {
    border-radius: 4px;
    cursor: pointer;
    font-size: 13px;
    padding: 6px 12px;
    text-decoration: none;
    width: 160px;
}

</style>

